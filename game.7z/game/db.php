<? 
$i=10;
while ((!($erg=mysql_pconnect("localhost","haqxscom_admin1","marco99168")))&&($i!=0)){$i--;}
if (!$erg) DIE ("Unable to connect to database.");
mysql_select_db("haqxscom_rpg");
?>