
WebRPG
======


WebRPG is a Browsergame. You don't have to download or install anything to play it.
It also doesn't use java or flash, just html and javascript.

WebRPG is a multiplayer role playing game. It runs on every common browser out there.
You can walk around, kill monsters, find items with different attributes, equip your
character ...

Try it, it's free! => http://webrpg.mpe-online.org



Installation
------------

You need a webserver with php and mysql installed.

1. Upload the webrpg directory to your webserver.
2. Create a database in mysql and import sql.txt to it. phpMyAdmin does the job.
3. Adjust db.php to your mysql account settings.

Done. 

Enjoy your installation of WebRPG and continue to develop it!



Marc
Millenium Project Enterprises
http://www.mpe-online.org
